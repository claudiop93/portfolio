create table dining_table
	(tableID		INT(3),
	 capacity		INT(3),
	 primary key (tableID)
	);


create table reservation
	(tableID		INT(3), 
	 name		varchar(20), 
	 phone		varchar(15),
	 guests		INT(3) DEFAULT 0,
	 primary key (name, phone, tableID),
	 foreign key (tableID) references dining_table (tableID)
		on delete set null
	);

delete from dining_table;
delete from reservation;
insert into dining_table values (1, 2);
insert into dining_table values (2, 2);
insert into dining_table values (3, 3);
insert into dining_table values (4, 3);
insert into dining_table values (5, 4);
insert into dining_table values (6, 4);
insert into dining_table values (7, 5);
insert into dining_table values (8, 5);
insert into dining_table values (9, 6);
insert into dining_table values (10, 6);