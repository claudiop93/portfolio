import mysql.connector

dbconn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="admin",
    database="Project"
)
dbcur = dbconn.cursor(buffered=True)


def show(s):  # this function shows the reservation for phoneNumberOrBookingName
    temp = s.split()
    num_nam = temp[1]
    # computing the query as a sum of strings
    query = "SELECT reservation.tableID, reservation.guests, dining_table.capacity, reservation.phone, " \
            "reservation.name FROM reservation, dining_table " \
            "WHERE reservation.tableID=dining_table.tableID AND (reservation.phone=\""
    query = str(query) + str(num_nam) + "\" OR reservation.name=\""
    query = str(query) + str(num_nam) + "\")"
    dbcur.execute(query)
    nRows = dbcur.rowcount  # if the query gives empty result (no rows), raise an error:
    if nRows == 0:
        print("Error")
    dbres = dbcur.fetchall()
    for x in dbres:
        print(*x)


def undo_res(s):  # this function cancels an existing reservation
    temp = s.split()
    num_nam = temp[1]
    row = "SELECT * FROM reservation"  # this line and the next 2 ones count how many rows are initially in the table
    dbcur.execute(row)
    nRows_old = dbcur.rowcount
    query = "DELETE FROM reservation WHERE phone=\""
    query = str(query) + str(num_nam) + "\" OR name=\""
    query = str(query) + str(num_nam) + "\""
    dbcur.execute(query)  # this executes the delete. In case of missing value, nothing gets deleted from the table.
    dbcur.execute(row)  # again, let's count how many rows are there after the DELETE:
    nRows_new = dbcur.rowcount
    if nRows_old == nRows_new:  # if the number of rows didn't change, raise an error since there was no DELETE done
        print("Error")
    dbconn.commit()


def list_all():  # List all the reservations
    query = "SELECT reservation.tableID, reservation.guests, dining_table.capacity, reservation.phone, " \
            "reservation.name FROM reservation, dining_table WHERE reservation.tableID=dining_table.tableID"
    dbcur.execute(query)
    dbres = list(dbcur.fetchall())
    if not dbres:  # this is meant to check if the result is empty
        print("No result(s)")
    else:
        for x in dbres:
            print(*x)


def list_unres():  # List all the unreserved tables
    query = "SELECT * FROM dining_table WHERE tableID NOT IN (SELECT tableID FROM reservation)"
    dbcur.execute(query)
    dbres = list(dbcur.fetchall())
    if not dbres:
        print("No result(s)")
    else:
        for x in dbres:
            print(*x)


def res_num():  # Output the number of reserved tables
    query = "SELECT COUNT(tableID) FROM reservation"
    dbcur.execute(query)
    dbres = list(dbcur.fetchone())
    print(dbres[0])


def res_num_g(s):  # Output the number of reserved tables with g guests
    temp = s.split()
    num_nam = temp[1]
    query = "SELECT COUNT(tableID) FROM reservation WHERE guests=" + str(num_nam)
    dbcur.execute(query)
    dbres = list(dbcur.fetchone())
    if not dbres:
        print("No result(s)")
    else:
        for x in dbres:
            print(x)


def overall_guests():  # Output the number of booked guests overall
    query = "SELECT SUM(guests) FROM reservation"
    dbcur.execute(query)
    dbres = list(dbcur.fetchone())
    for x in dbres:
        print(x)


def left_capacity():  # Output the number of unreserved seats overall
    query1 = "SELECT SUM(capacity) FROM dining_table"
    dbcur.execute(query1)
    dbres = list(dbcur.fetchone())  # computes the sum of all seats
    query2 = "SELECT SUM(guests) FROM reservation"
    dbcur.execute(query2)
    guests = list(dbcur.fetchone())  # sum of all booked seats
    num = int(dbres[0]) - int(guests[0])  # total seats - booked
    return num


def max_unres():  # Show the information about table(s) with the greatest number of unreserved seats
    # the first query creates a view with table, seats and booked guests per table. it's a left join because I need to
    # include every table in dining_table. null values are transformed into 0 (it means the table is unbooked)
    query1 = "CREATE OR REPLACE VIEW temp AS SELECT dining_table.tableID, " \
             "IFNULL(reservation.guests, 0) AS guests, dining_table.capacity FROM dining_table " \
             "LEFT JOIN reservation ON reservation.tableID=dining_table.tableID"
    # the second query creates a new view, from the first one, with the table id and a new column
    # containing all free seats per table given by total capacity - booked seats
    query2 = "CREATE OR REPLACE VIEW temp1 AS SELECT tableID, (capacity-guests) AS unres FROM temp"
    # the last query selects the table with maximum free seats
    query3 = "SELECT * FROM temp WHERE tableID IN " \
             "(SELECT tableID from temp1 where unres=(select max(unres) from temp1))"
    dbcur.execute(query1)
    dbcur.execute(query2)
    dbcur.execute(query3)
    dbres = list(dbcur.fetchall())
    for x in dbres:
        print(*x)


def max_b_unres():  # Show the information about reserved table(s) with the greatest number of unreserved seats
    # this function does the same as max_unres(), but the first query is a simple join and not a left join, since
    # we don't need to keep count of unreserved tables
    query1 = "CREATE OR REPLACE VIEW temp AS SELECT dining_table.tableID, IFNULL(reservation.guests, 0) AS guests, " \
             "dining_table.capacity FROM dining_table JOIN reservation ON reservation.tableID=dining_table.tableID"
    query2 = "CREATE OR REPLACE VIEW temp1 AS SELECT tableID, (capacity-guests) AS unres FROM temp"
    query3 = "SELECT * FROM temp WHERE tableID IN " \
             "(SELECT tableID from temp1 where unres=(select max(unres) from temp1))"
    dbcur.execute(query1)
    dbcur.execute(query2)
    dbcur.execute(query3)
    dbres = list(dbcur.fetchall())
    for x in dbres:
        print(*x)


def reservation(s):  #  this makes a reservation
    temp = s.split()  # splitting the string in parts to create the right query
    g = str(temp[1])
    num = str(temp[2])
    name = str(temp[3])
    # this query will select a free table with enough seats for the number of guests. It has a condition on a subquery:
    # it will exclude every table that already have guests;
    # The SELECT MIN(tableID) is just a way to make sure that only one table gets reserved at a time.
    free_table = "SELECT MIN(tableID) FROM dining_table WHERE (tableID NOT IN (SELECT tableID FROM reservation)) " \
                 "AND capacity >= " + g
    try:
        dbcur.execute(free_table)
    except:
        print("Error")
        return
    tableid = dbcur.fetchone()
    tableid = tableid[0]
    # reserving the table selected with the previous query
    insert = "INSERT INTO reservation VALUES (" + str(tableid) + ",\'" + name + "\',\'" + num + "\'," + g + ")"
    try:
        dbcur.execute(insert)
    except:
        print("Error")
        return
    dbconn.commit()


def main():
    s = ""
    while s != 'X':
        s = str(input(">"))
        if s == 'L':
            list_all()
        elif s == 'U':
            list_unres()
        elif s == 'NT':
            res_num()
        elif s == 'NG':
            overall_guests()
        elif s == 'NU':
            print(left_capacity())
        elif s == 'GU':
            max_unres()
        elif s == 'GR':
            max_b_unres()
        elif s[0:2] == 'NT' and len(s) > 2:
            res_num_g(s)
        elif s[0:2] == 'R ':
            reservation(s)
        elif s[0:2] == 'S ':
            show(s)
        elif s[0:2] == 'C ':
            undo_res(s)
        elif s != 'X':  # this is just in case of typos when selecting a function
            print("No result(s)")


main()

dbcur.close()
dbconn.close()